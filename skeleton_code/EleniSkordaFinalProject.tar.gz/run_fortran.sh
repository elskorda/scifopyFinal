#!/bin/sh
rm paticle.state
export PATH=./bin:$PATH
particles
