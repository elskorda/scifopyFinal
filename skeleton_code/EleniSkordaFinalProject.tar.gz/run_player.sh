#!/bin/sh

export PATH=./bin:$PATH
export PYTHONPATH=./bin:$PYTHONPATH
python3 particle_player.py
